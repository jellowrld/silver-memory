
import requests
import random
import time
import concurrent.futures
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By

# Configuration
VIDEO_URL = "https://youtube.com/watch?v=tNdje4dwrD0"
CHROMEDRIVER_PATH = "/path/to/chromedriver"  # Replace with your actual chromedriver path
NUM_VIEWERS = 5
WATCH_DURATION = 60  # Seconds per viewer
MAX_RETRIES = 3      # Retry attempts per viewer

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_2_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.3 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 16_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; Android 12; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.5790.136 Mobile Safari/537.36",
    "Mozilla/5.0 (iPad; CPU OS 15_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 Mobile/15E148 Safari/604.1"
]

def fetch_proxies(limit=100):
    url = f"https://proxylist.geonode.com/api/proxy-list?limit={limit}&page=1&sort_by=lastChecked&sort_type=desc"
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        data = response.json()
        return data.get("data", [])
    except Exception as e:
        print(f"[ERROR] Failed to fetch proxies: {e}")
        return []

def validate_proxy(proxy_str, timeout=5):
    try:
        proxies = {"http": f"http://{proxy_str}", "https": f"http://{proxy_str}"}
        response = requests.get("https://www.google.com", proxies=proxies, timeout=timeout)
        return response.status_code == 200
    except:
        return False

def get_working_https_proxies(proxy_list, max_to_test=50):
    https_proxies = []
    print("[INFO] Validating proxies...")
    for proxy in proxy_list[:max_to_test]:
        if "https" not in proxy.get("protocols", []):
            continue
        proxy_str = f"{proxy['ip']}:{proxy['port']}"
        if validate_proxy(proxy_str):
            https_proxies.append(proxy_str)
            print(f"[OK] {proxy_str}")
        else:
            print(f"[FAIL] {proxy_str}")
    return https_proxies

def get_proxy_options(proxy_str):
    options = webdriver.ChromeOptions()
    options.add_argument("--mute-audio")
    options.add_argument("--start-maximized")
    options.add_argument("--incognito")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument("--headless=new")
    user_agent = random.choice(USER_AGENTS)
    options.add_argument(f"user-agent={user_agent}")
    options.add_argument(f'--proxy-server=http://{proxy_str}')
    return options

def launch_viewer(viewer_id, proxy, retry=0):
    print(f"[Viewer {viewer_id}] Launching with proxy: {proxy} (Attempt {retry + 1})")
    options = get_proxy_options(proxy)
    try:
        driver = webdriver.Chrome(service=Service(CHROMEDRIVER_PATH), options=options)
        driver.get(VIDEO_URL)
        print(f"[Viewer {viewer_id}] Page title: {driver.title}")
        time.sleep(random.uniform(5, 10))
        try:
            play_button = driver.find_element(By.CSS_SELECTOR, "button.ytp-large-play-button")
            play_button.click()
        except:
            pass
        print(f"[Viewer {viewer_id}] Watching...")
        time.sleep(WATCH_DURATION)
    except Exception as e:
        print(f"[Viewer {viewer_id}] Error: {e}")
        if retry < MAX_RETRIES:
            launch_viewer(viewer_id, proxy, retry + 1)
    finally:
        try:
            driver.quit()
        except:
            pass
        print(f"[Viewer {viewer_id}] Closed.")

def run_viewers_with_validated_proxies(num_viewers):
    raw_proxies = fetch_proxies()
    working_proxies = get_working_https_proxies(raw_proxies)
    if not working_proxies:
        print("[ERROR] No working HTTPS proxies found.")
        return
    with concurrent.futures.ThreadPoolExecutor(max_workers=num_viewers) as executor:
        futures = []
        for i in range(num_viewers):
            proxy = random.choice(working_proxies)
            futures.append(executor.submit(launch_viewer, i + 1, proxy))
        concurrent.futures.wait(futures)

if __name__ == "__main__":
    run_viewers_with_validated_proxies(NUM_VIEWERS)
